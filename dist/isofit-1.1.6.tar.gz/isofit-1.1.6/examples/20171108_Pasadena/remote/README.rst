This subdirectory contains remote AVIRIS-NG observations 
