This directory contains the output including estimated reflectance files, 
algebraic inversion files, modeled radiance files, and posterior error files.
