This directory contains in situ reflectance and sunphotometer measurements from the Pasadena experiment
