Surface model source data in ENVI format:

surface_model_usgs - The USGS spectral library version 7: Kokaly, R.F., Clark, R.N., Swayze, G.A., Livo, K.E., Hoefen, T.M., Pearson, N.C., Wise, R.A., Benzel, W.M., Lowers, H.A., Driscoll, R.L., and Klein, A.J., 2017, USGS Spectral Library Version 7 Data: U.S. Geological Survey data release, https://dx.doi.org/10.5066/F7RR1WDJ.

surface_model_ucsb - A dataset of urban materials from the University of California Santa Barbara:  M. Herold D.A. Roberts M.E. Gardner and P.E. Dennison. 2004. Urban Reflectance Spectra from Santa Barbara, CA. Data set. Available on-line [http://ecosis.org] from the Ecological Spectral Information System (EcoSIS)
